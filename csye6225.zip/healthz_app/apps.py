from django.apps import AppConfig


class HealthzAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'healthz_app'
